// Firebase config for SAP Job Automator
// This file is gitignored — never commit real credentials.
window.__FIREBASE_CONFIG__ = {
  apiKey: "AIzaSyDG0VBXMrUdxzpw3Hwwrsr_oRtiVg_vSuM",
  authDomain: "jobs-progress-tracker.firebaseapp.com",
  projectId: "jobs-progress-tracker",
  storageBucket: "jobs-progress-tracker.firebasestorage.app",
  messagingSenderId: "556518693770",
  appId: "1:556518693770:web:2df595285bf3ec199f0673",
  measurementId: "G-8JNFN5X2RE"
};
